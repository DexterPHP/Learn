<!DOCTYPE html>


<html lang="ar" dir="rtl">
<head>

    <meta http-equiv="Content-Language" content="ar">
    <meta http-equiv="content-Type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">

    <!--IE Compatibility Meta-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--Mobile Meta-->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.rtl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/devicon.min.css')); ?>">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/favicon.png')); ?>">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('images/favicon.png')); ?>">

    <!--[if lt IE 9]>
    <script src="<?php echo e(asset('js/html5shiv.min.js')); ?>assets/js/"></script>
    <script src="<?php echo e(asset('js/respond.min.js')); ?>"></script>
    <![endif]-->

</head>

<body>

<script>
    var siteUrl = "dex-ter.site";
</script>


<?php /**PATH C:\xampp\htdocs\ITcorses\resources\views/pages/Main_header.blade.php ENDPATH**/ ?>