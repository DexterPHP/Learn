<?php echo $__env->make('pages.Main_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php if(isset($getplaylist) and isset($cater)): ?>

    <div class="page-heading title-lg">
        <div class="container">
            <div class="container">

                <div class="row">

                    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
                        <h3>
                            <a style="text-decoration: none;" href="../" target="_blank" title="<?php echo e($getplaylist->title); ?>">
                               <?php echo e($getplaylist->title); ?>

                                <title>ويكي كورس |
                                    <?php echo e($getplaylist->title); ?>

                                     |<?php echo e(json_decode($getplaylist->fulldata)->lessons[$id]->title); ?>


                                </title>
                            </a>
                        </h3>

                        <ul class="page-meta">
                            <li>
                                <i class="fa fa-tags"></i>
                                <a href="/MainCourse/<?php echo e(trim($Main)); ?>" style="text-decoration: none;" class="subject-label" title="<?php echo e($Main); ?>"><?php echo e(trim($Main)); ?></a>
                                <a href="../" style="text-decoration: none;" class="subject-label" title="<?php echo e(trim($SubMain)); ?>"><?php echo e(trim($SubMain)); ?></a>
                            </li>
</ul>
                    </div>

                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                        <div class="page-options">

                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
    <div class="lessons">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                    <div class="lesson-player">
                        <div class="lesson">
                            <h3 class="text-right"><?php echo e(json_decode($getplaylist->fulldata)->lessons[$id]->title); ?></h3>
                                <link rel="stylesheet" href="<?php echo e(asset('css/plyr.css')); ?>" />

                               <video poster="<?php echo e(json_decode($getplaylist->fulldata)->cover ? json_decode($getplaylist->fulldata)->cover : '/images/cover.png'); ?>" id="player" playsinline controls>
                                    <source src="<?php echo e(json_decode($getplaylist->fulldata)->lessons[$id]->url); ?>" type="video/mp4" />
                                   Your browser does not support the video tag.
                                </video>

                                <script src="<?php echo e(asset('js/plyr.js')); ?>"></script>
                                <script>
                                    const player = new Plyr('#player',{
                                        'autoplay' : true,
                                        'controls' :['play-large', 'play', 'progress', 'current-time', 'mute', 'volume', 'captions', 'settings', 'pip', 'airplay', 'fullscreen'],
                                        'setting' : ['captions', 'quality', 'speed', 'loop'],
                                        'volume': 1,
                                        'muted': false,
                                        // Display tooltips
                                        'tooltips': {
                                            'controls': true,
                                            'seek': true,
                                        },
                                        // Sprite (for icons)
                                        'loadSprite': true,
                                        'iconPrefix': 'plyr',
                                        'iconUrl': 'https://cdn.plyr.io/3.5.10/plyr.svg',


                                    });

                                </script>


                        </div>

                    </div>

                    <div class="lesson-page">
                        <p class="text-left">Video Title: <b><?php echo e(json_decode($getplaylist->fulldata)->lessons[$id]->title); ?></b></p>
                        <p class="text-left">Video Duration: <b><?php echo e(json_decode($getplaylist->fulldata)->lessons[$id]->time); ?></b></p>
                        <p class="text-left">Video Quilty: <b><?php echo e(json_decode($getplaylist->fulldata)->lessons[$id]->Quilty); ?></b></p>
                        <p class="text-left">Video Download Size: <b><?php echo e(json_decode($getplaylist->fulldata)->lessons[$id]->size); ?></b></p>
                        <p class="text-left"> :Video Tags<br /><br />
                            <?php
                                $vars = explode(' ',json_decode($getplaylist->fulldata)->lessons[$id]->title);
                                foreach ($vars as $tags){
                                    $result = preg_replace("/[^a-zA-Z0-9]+^[\u0621-\u064A0-9 ]+$/", "", $tags);
                                    if(strlen($result) > 2){
                                        echo '<i class="fa fa-tags"></i><a href="/search?query='.$tags.'" style="text-decoration: none;" class="subject-label" title="'.$tags.'">'.$tags.'</a>
                                         ';
                                    }
                                }
                            ?>
                        </p>
                        <a href="<?php echo e(json_decode($getplaylist->fulldata)->lessons[$id]->url); ?>"
                           title="Download <?php echo e(json_decode($getplaylist->fulldata)->lessons[$id]->title); ?>" download class="btn btn-danger align-self-center">
                            Download Now  <?php echo e(json_decode($getplaylist->fulldata)->lessons[$id]->Quilty); ?>

                            [<?php echo e(json_decode($getplaylist->fulldata)->lessons[$id]->size); ?>]
                        </a>

                    </div>

                    <br /><br />
                    <div class="lessons-list">
                        <h3><i class="fa fa-bars"></i> قائمة الدروس</h3>
                        <ul>
                            <?php $i=1; ?>
                           <?php $__currentLoopData = json_decode($getplaylist->fulldata)->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li <?php if(($id+1) == ($i)): ?> style="background: #e3dbdb;" <?php endif; ?>>
                                    <a href="<?php echo e($i); ?>">
                                        <div class="lesson-icon">
                                            <?php if(($id+1) == ($i)): ?>
                                                <i class="fa fa-pause"></i>
                                            <?php else: ?>
                                                <i class="fa fa-play-circle"></i>
                                            <?php endif; ?>

                                        </div>

                                        <div class="lesson-title"><?php echo e($video->title); ?></div>
                                        <div class="lesson-duration">
                                            <b>المدة: <?php echo e($video->time); ?></b> -
                                            <b>الوصف:</b>
                                            <?php echo e(substr(str_replace('=',' ',$video->descr),0,100)); ?>

                                        </div>
                                    </a>
                                </li>
                               <?php $i=$i+1; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>



                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">

                    <?php if(strlen($getplaylist->full_link) > 5): ?>
                        <div class="widget">
                            <h3><i class="fa fa-download">
                                </i> تحميل الكورس كاملاً </h3>

                            <div class="form-group">
                                <a href="<?php echo e($getplaylist->full_link); ?>" class="btn btn-primary center-block btn-lg" style="background-color: #25d366;border: 1px solid #25d366" download="" title="Download Full Course as rar or zip file" >Download  Full Course Now</a>
                            </div>

                        </div>
                    <?php endif; ?>

                    <div class="widget">
                        <h3><a href="/" target="_blank"><img src="/images/corses.png" alt="" /></a></h3>
                        <div class="widget-body">

                            <ul class="articles-list">


                                <?php $__currentLoopData = $collect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <div class="article-item">
                                            <a href="/c/<?php echo e($coll->id); ?>" target="_blank">
                                                <img src="<?php echo e($coll->logo); ?>" alt="" /><?php echo e($coll->title); ?></a>
                                            <div class="article-date"><?php echo e($coll->created_at); ?></div>
                                        </div>
                                        <div style="clear: both;"></div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </div>
                    </div>

                    <div class="widget share-course">
                        <h3><i class="fa fa-share-alt"></i> شارك الكورس</h3>

                        <div class="course-link-input">

                            <input class="form-control" onclick="selectInput(this)" value="https://wikicourses.net/c/<?php echo e(($getplaylist)->id); ?>" readonly="">
                        </div>
                        <?php
                            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                        ?>
                        <ul class='list-unstyled share-buttons'>

                            <li>
                                <a class='sharing-button facebook' href='https://facebook.com/sharer/sharer.php?u=<?php echo e($actual_link); ?>' title='facebook' target='_blank'>
                                    <i class='fa fa-facebook'></i>
                                </a>
                            </li>

                            <li>
                                <a class='sharing-button twitter' href='https://twitter.com/intent/tweet/?text=<?php echo e($getplaylist->title); ?>&url=<?php echo e($actual_link); ?>' title='twitter' target='_blank'>
                                    <i class='fa fa-twitter'></i>
                                </a>
                            </li>

                            <li>
                                <a class='sharing-button email' href='mailto:?subject=<?php echo e($getplaylist->title); ?>&body=<?php echo e($actual_link); ?>' title='email' target='_self'>
                                    <i class='fa fa-envelope'></i>
                                </a>
                            </li>

                            <li>
                                <a class='sharing-button whatsapp' href='https://api.whatsapp.com/send?text=<?php echo e($actual_link); ?>' title='whatsapp' target='_blank'>
                                    <i class='fa fa-whatsapp'></i>
                                </a>
                            </li>

                        </ul>
                    </div>

                        <div class="widget">
                            <h3><i class="fa fa-download">
                                </i> مصدر الدورة الرئيسي   </h3>

                            <div class="form-group">
                                <a href="<?php echo e($getplaylist->playlist_link); ?>" class="btn btn-danger center-block btn-lg" target="_blank" download="" title="رابط المصدر الرئيسي" >رابط المصدر</a>
                            </div>
                            <p class="text-warning">
                                فنحن لا ندعي ملكية أي دورة ولهذا نضع المصدر الأصلي لكم
                            </p>
                        </div>

                </div>
            </div>

        </div>
    </div>
<?php endif; ?>
<?php echo $__env->make('pages.Main_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/wikicourses/resources/views/view_lesson.blade.php ENDPATH**/ ?>