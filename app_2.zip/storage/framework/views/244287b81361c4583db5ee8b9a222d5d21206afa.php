<?php echo $__env->make('pages.Main_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Header And Navbar -->
<!--Navbar-->
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">

        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#ourNavbar">
                <i class="fa fa-bars"></i>
            </button>

            <a class="navbar-brand coursat-logo-main" href="/"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="كورسات"></a>
            <a class="navbar-brand coursat-logo-mobile" href="/"><img src="<?php echo e(asset('images/logo-mobile.png')); ?>" alt="كورسات"></a>
        </div>

        <div class="collapse navbar-collapse" id="ourNavbar">

            <ul class="nav navbar-nav navbar-right">

                <div class="mobile-search hidden-lg hidden-md hidden-sm">
                    <div class="container">
                        <form action="/search" method="get" role="search">
                            <input class="form-control" type="text" name="query" placeholder="أكتب كلمة البحث ...">
                        </form>
                    </div>
                </div>

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-th-large"></i> التصنيفات <span class="caret"></span></a>
                    <ul class="dropdown-menu categories-menu" role="menu">
                        <?php $__currentLoopData = $cater; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="MainCourse/<?php echo e($coco->title_en); ?>"><?php echo e($coco->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </li>

            </ul>

            <ul class="nav navbar-nav navbar-left">

                <li class="hidden-xs" data-toggle="tooltip" data-placement="bottom" title="البحث">
                    <a href="javascript:;" id="search-button"><i class="fa fa-search fa-lg"></i></a>
                </li>




            </ul>

        </div>
    </div>

    <div id="search-bar">
        <div class="container">
            <form action="https://www.coursat.org/search" id="search-form" method="get" role="search">
                <input class="form-control" id="search-input" type="text" name="query" placeholder="أكتب كلمة البحث ...">
            </form>
        </div>
    </div>

</nav>

<title>كورسات | كورسات مجانية عالية الجودة</title>
<meta name='description' content='كورسات هي منصة عربية توفر كورسات مجانية عالية الجودة في مختلف المجالات والتخصصات تسعى إلى رفع مستوى التعليم الإلكتروني في الوطن العربي كما توفر فرصة لاصحاب الكفاءات والخبرات والمدرسين للوصول إلى جمهور أكبر'>
<meta name='keywords' content='كورسات,coursat,coursat.org,كورسات وشروحات,كورسات عربي,كورسات مجانية,courses,acoderlab,سمات,semaat,كورسات لغات,كورسات برمجة,كورسات تصميم,كورسات اون لاين,دورات مجانية,شهادات معتمدة,دورات اون لاين,شهادات مجانية,موقع كورسات,منصة كورسات,corsat,كورس,موقع كورسات مجانية'>

<?php if(isset($datacater) and isset($Sub)): ?>
    <div class="page-heading title-lg">
        <div class="container">
            <h3><?php echo e($Sub->title); ?></h3>
        </div>
    </div>
<section class="subjects text-center">
<div class="container">

    <div class="text-center google-ads" style="margin-bottom: 20px;">
        <script async="" src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5531479841914155" data-ad-slot="7819034443" data-ad-format="auto"></ins>
        <script>
            (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>
    <div class="row">
      <?php $__currentLoopData = $datacater; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SubCater): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                <a href="/Courses/<?php echo e(trim($Sub->title_en)); ?>/<?php echo e($SubCater->title_en); ?>">
                    <div class="subject-box">
                        <div class="box-icon">
                            <i class="<?php echo e($SubCater->logo); ?> colored"></i>
                        </div>
                        <div class="box-title"><?php echo e($SubCater->title); ?></div>
                    </div>
                </a>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
</section>
<?php endif; ?>
<?php echo $__env->make('pages.Main_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ITcorses\resources\views/viewSub.blade.php ENDPATH**/ ?>