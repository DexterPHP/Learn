<?php echo $__env->make('pages.Main_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="<?php echo e(asset('css/error_page.css')); ?>" rel="stylesheet" />
<div class="errorPage" style="margin: 60px;">
    <h1>سياسة الخصوصية</h1>


    <h3 class="text-right">سياسية الموقع الداخلية:</h3>

    <h5 class="text-right">
        في موقعنا لا نجمع معلومات أبداً عن الزوار مهما كانت بساطة هذه المعلومات، في حالة اقترح كورس أو طلب كورس نحن نجمع عناوين البريد الإلكترونيي الخاص بالمقترحين والطالبين فقط وذلك لإمكانية الرد عليهم برسالة خاصة لهم على عناوينهم.
    </h5>
    <br />

    <h3 class="text-right">روابط إلى مواقع إلكترونية أخرى:</h3>

    <h5 class="text-right">
        قد يحتوي الموقع روابط إلى مواقع إلكترونية للغير كمزودي محتوى آخرين وبعض مزودي الخدمات، غير أن هذه المواقع الأخرى ليست تحت إدارتنا وبذلك عليك أن تتفهم وتوافق على أننا لا نتحمل مسؤولية جمع هذه المواقع واستخدامها لمعلوماتك ما لم تتم الإشارة له بغير ذلك في سياسة الخصوصية هذه. نوصيكم بالحرص عندما يتم توجيهكم إلى موقع الغير لتقوموا بمراجعة سياسات الخصوصية لكل موقع تزورونه وتستخدمونه.
    </h5>
    <br />

    <h3 class="text-right">اتصلوا بنا:</h3>

    <h5 class="text-right">
        إذا كانت لديكم أي أسئلة بخصوص سياسة حماية الخصوصية، نرجو منكم الاتصال بنا من خلال النقر
        <a href="#">هنا</a> .
    </h5>
    <br />









</div>
<?php echo $__env->make('pages.Main_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/wikicourses/resources/views/main/privacy-policy.blade.php ENDPATH**/ ?>