<?php echo $__env->make('pages.Main_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(isset($datacater) and isset($Sub)): ?>
    <div class="page-heading title-lg">
        <div class="container">
            <h3><?php echo e($Sub->title); ?></h3>
            <title>
                ويكي كورس | كورسات مجانية
            | <?php echo e($Sub->title); ?>

            </title>
        </div>
    </div>
<section class="subjects text-center">
<div class="container">


    <div class="row">
      <?php $__currentLoopData = $datacater; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SubCater): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
                <a href="/Courses/<?php echo e(trim($Sub->title_en)); ?>/<?php echo e(trim($SubCater->title_en)); ?>">
                    <div class="subject-box">
                        <div class="box-icon">
                            <i class="<?php echo e($SubCater->logo); ?> colored"></i>
                        </div>
                        <div class="box-title"><?php echo e($SubCater->title); ?></div>
                    </div>
                </a>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</div>
</section>
<?php endif; ?>

<?php echo $__env->make('pages.Main_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/wikicourses/resources/views/viewSub.blade.php ENDPATH**/ ?>