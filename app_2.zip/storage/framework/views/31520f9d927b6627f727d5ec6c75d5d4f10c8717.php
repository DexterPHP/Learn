<?php echo $__env->make('pages.Main_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Header And Navbar -->
<!--Navbar-->
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">

        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#ourNavbar">
                <i class="fa fa-bars"></i>
            </button>

            <a class="navbar-brand coursat-logo-main" href="/><img src="<?php echo e(asset('images/logo.png')); ?>" alt="كورسات"></a>
            <a class="navbar-brand coursat-logo-mobile" href="/"><img src="<?php echo e(asset('images/logo-mobile.png')); ?>" alt="كورسات"></a>
        </div>

        <div class="collapse navbar-collapse" id="ourNavbar">

            <ul class="nav navbar-nav navbar-right">

                <div class="mobile-search hidden-lg hidden-md hidden-sm">
                    <div class="container">
                        <form action="/search" method="get" role="search">
                            <input class="form-control" type="text" name="query" placeholder="أكتب كلمة البحث ...">
                        </form>
                    </div>
                </div>

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-th-large"></i> التصنيفات <span class="caret"></span></a>
                    <ul class="dropdown-menu categories-menu" role="menu">
                       <?php $__currentLoopData = $cater; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="MainCourse/<?php echo e($coco->title_en); ?>"><?php echo e($coco->title); ?></a></li>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </li>

            </ul>

            <ul class="nav navbar-nav navbar-left">

                <li class="hidden-xs" data-toggle="tooltip" data-placement="bottom" title="البحث">
                    <a href="javascript:;" id="search-button"><i class="fa fa-search fa-lg"></i></a>
                </li>




            </ul>

        </div>
    </div>

    <div id="search-bar">
        <div class="container">
            <form action="https://www.coursat.org/search" id="search-form" method="get" role="search">
                <input class="form-control" id="search-input" type="text" name="query" placeholder="أكتب كلمة البحث ...">
            </form>
        </div>
    </div>

</nav><title>كورسات | كورسات مجانية عالية الجودة</title><meta name='description' content='كورسات هي منصة عربية توفر كورسات مجانية عالية الجودة في مختلف المجالات والتخصصات تسعى إلى رفع مستوى التعليم الإلكتروني في الوطن العربي كما توفر فرصة لاصحاب الكفاءات والخبرات والمدرسين للوصول إلى جمهور أكبر'>
<meta name='keywords' content='كورسات,coursat,coursat.org,كورسات وشروحات,كورسات عربي,كورسات مجانية,courses,acoderlab,سمات,semaat,كورسات لغات,كورسات برمجة,كورسات تصميم,كورسات اون لاين,دورات مجانية,شهادات معتمدة,دورات اون لاين,شهادات مجانية,موقع كورسات,منصة كورسات,corsat,كورس,موقع كورسات مجانية'>

<section class="coursat-intro text-center">
    <div class="intro-bg">
        <div class="container">

            <h2>ماذا تريد أن تتعلم ؟</h2>

            <div class="search-box">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 col-lg-offset-* col-md-8 col-md-offset-2 col-md-offset-* col-sm-12 col-xs-12">
                        <div id="search-form">
                            <form role="search" method="get" id="searchform" action="search">
                                <input type="text" class="search-input" name="query" placeholder="ابحث عن كورس ... مثال : PHP , Java , Calculus , Photoshop">
                                <button type="submit" id="searchsubmit" class="search-icon"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <div class="coursat-statistics">
                        <i class="fa fa-laptop"></i>
                        <h3>255 كورس</h3>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <div class="coursat-statistics">
                        <i class="fa fa-users"></i>
                        <h3>48.3 ألف طالب</h3>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <div class="coursat-statistics">
                        <i class="fa fa-play-circle-o"></i>
                        <h3>10.8 ألف درس</h3>
                    </div>
                </div>

                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <div class="coursat-statistics">
                        <i class="fa fa-clock-o"></i>
                        <h3>2.4 ألف                                ساعة تعليمية</h3>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<!-- Header And Navbar -->

<section class="categories categories-home text-center">
    <div class="container">
        <div class="big-title">
            <h2>تصنيفات الكورسات</h2>
            <div class="hr-title"></div>
        </div>

        <div class="text-center google-ads" style="margin-bottom: 20px;">
            <script async="" src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
            <ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5531479841914155" data-ad-slot="5101371760" data-ad-format="auto" data-full-width-responsive="true"></ins>
            <script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
        </div>
        <div class="row">

            <?php $__currentLoopData = $cater; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                    <a href="MainCourse/<?php echo e($category->title_en); ?>">
                        <div class="category-box" title="<?php echo e($category->description); ?>">
                            <div class="category-cover" style="background:url('<?php echo e($category->image_link); ?>') no-repeat center center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;">
                                <div class="category-overlay">
                                    <div class="thumb-content">
                                        <div class="category-icon">
                                            <i class="<?php echo e($category->icon_link); ?>"></i>
                                        </div>
                                        <div class="category-name"><?php echo e($category->title); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <a href="MainCourse" class="btn all-categories-btn"><i class="fa fa-th-large"></i> عرض جميع التصنيفات</a>
            </div>

        </div>

    </div>
</section>


<?php echo $__env->make('pages.Main_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ITcorses\resources\views/index.blade.php ENDPATH**/ ?>