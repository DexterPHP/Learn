<?php echo $__env->make('pages.Main_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Header And Navbar -->
<!--Navbar-->
<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">

        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#ourNavbar">
                <i class="fa fa-bars"></i>
            </button>

            <a class="navbar-brand coursat-logo-main" href="/"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="كورسات"></a>
            <a class="navbar-brand coursat-logo-mobile" href="/"><img src="<?php echo e(asset('images/logo-mobile.png')); ?>" alt="كورسات"></a>
        </div>

        <div class="collapse navbar-collapse" id="ourNavbar">

            <ul class="nav navbar-nav navbar-right">

                <div class="mobile-search hidden-lg hidden-md hidden-sm">
                    <div class="container">
                        <form action="/search" method="get" role="search">
                            <input class="form-control" type="text" name="query" placeholder="أكتب كلمة البحث ...">
                        </form>
                    </div>
                </div>

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-th-large"></i> التصنيفات <span class="caret"></span></a>
                    <ul class="dropdown-menu categories-menu" role="menu">
                        <?php $__currentLoopData = $cater; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="MainCourse/<?php echo e($coco->title_en); ?>"><?php echo e($coco->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </li>

            </ul>

            <ul class="nav navbar-nav navbar-left">

                <li class="hidden-xs" data-toggle="tooltip" data-placement="bottom" title="البحث">
                    <a href="javascript:;" id="search-button"><i class="fa fa-search fa-lg"></i></a>
                </li>




            </ul>

        </div>
    </div>

    <div id="search-bar">
        <div class="container">
            <form action="https://www.coursat.org/search" id="search-form" method="get" role="search">
                <input class="form-control" id="search-input" type="text" name="query" placeholder="أكتب كلمة البحث ...">
            </form>
        </div>
    </div>

</nav>

<title>كورسات | كورسات مجانية عالية الجودة</title>
<meta name='description' content='كورسات هي منصة عربية توفر كورسات مجانية عالية الجودة في مختلف المجالات والتخصصات تسعى إلى رفع مستوى التعليم الإلكتروني في الوطن العربي كما توفر فرصة لاصحاب الكفاءات والخبرات والمدرسين للوصول إلى جمهور أكبر'>
<meta name='keywords' content='كورسات,coursat,coursat.org,كورسات وشروحات,كورسات عربي,كورسات مجانية,courses,acoderlab,سمات,semaat,كورسات لغات,كورسات برمجة,كورسات تصميم,كورسات اون لاين,دورات مجانية,شهادات معتمدة,دورات اون لاين,شهادات مجانية,موقع كورسات,منصة كورسات,corsat,كورس,موقع كورسات مجانية'>

<?php if(isset($Main) and isset($Sub) and isset($course)): ?>
    <div class="page-heading title-lg">
        <div class="container">
            <div class="container">

                <div class="row">

                    <div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
                        <h3>
                            <a style="text-decoration: none;" href="<?php echo e($data->playlist_link); ?>" target="_blank" title="">
                                <?php
                                    $title = @json_decode($course)->Channel->playlisinfo->title;
                                    echo @$title;
                                ?>
                            </a>
                        </h3>

                        <ul class="page-meta">
                            <li>
                                <i class="fa fa-tags"></i>
                                    <a href="/MainCourse/<?php echo e(trim($Main->title_en)); ?>" style="text-decoration: none;" class="subject-label" title="<?php echo e($Main->title); ?>"><?php echo e(trim($Main->title)); ?></a>
                                <a href="/Courses/<?php echo e(trim($Main->title_en)); ?>/<?php echo e(trim($Sub->title_en)); ?>" style="text-decoration: none;" class="subject-label" title="trim(<?php echo e($Sub->title); ?>)"><?php echo e(trim($Sub->title)); ?></a>
                            </li>


                            <li data-toggle="tooltip" data-placement="top" title="" data-original-title="المحاضر">
                                <i class="fa fa-user"></i>
                                <a href="##"> <?php echo e(@json_decode($course)->Channel->title); ?></a>
                            </li>
                            <li data-toggle="tooltip" data-placement="top" title="" data-original-title="اللغة"><i class="fa fa-globe"></i>   <?php echo e($data->language); ?></li>
                            <li data-toggle="tooltip" data-placement="top" title="" data-original-title="مدة الكورس"><i class="fa fa-clock-o"></i> <?php echo e($data->all_length); ?> </li>
                            <li data-toggle="tooltip" data-placement="top" title="" data-original-title="عدد الدروس"><i class="fa fa-play-circle"></i> <?php echo e($data->count_of_videos); ?></li>
                        </ul>
                    </div>

                    <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                        <div class="page-options">
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
    <div class="lessons">
        <div class="container">

            <div class="text-center google-ads" style="margin-bottom: 20px;">
                <script async="" src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
                <ins class="adsbygoogle" style="display:block" data-ad-client="ca-pub-5531479841914155" data-ad-slot="7819034443" data-ad-format="auto"></ins>
                <script>
                    (adsbygoogle = window.adsbygoogle || []).push({});
                </script>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                    <div class="lessons-list">
                        <h3><i class="fa fa-bars"></i> المحتويات</h3>
                        <ul>
                            <?php $__currentLoopData = json_decode($course)->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="/view_lesson/<?php echo e($data->id); ?>/<?php echo e($video->Number); ?>/<?php echo e($video->VedioData->videoid); ?>">
                                        <div class="lesson-icon"><i class="fa fa-play-circle"></i></div>
                                        <div class="lesson-icon"><?php echo e($video->Number); ?></div>
                                        <div class="lesson-title"><?php echo e($video->VedioData->title); ?></div>
                                        <div class="lesson-duration">
                                            <?php echo e(substr(str_replace('=',' ',$video->VedioData->description),0,100)); ?>

                                        </div>
                                    </a>
                                </li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                    <div class='pagination-centered'>
                        <ul class='pagination'>
                            <li><a class='current'>1</a></li>
                            <li><a href=''>2</a></li>
                            <li><a href=''>3</a></li>
                            <li><a data-toggle='tooltip' data-placement='top' title='التالي' href=''><i class='fa fa-angle-left'></i></a></li>
                            <li><a data-toggle='tooltip' data-placement='top' title='الأخيرة' href=''><i class='fa fa-angle-double-left'></i></a></li>
                        </ul>
                    </div>

                </div>

                <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">


                    <div class="widget">
                        <h3><i class="fa fa-star"></i>   <?php echo e(@json_decode($course)->Channel->title); ?></h3>
                        <div class="rating-result"><?php echo e(@json_decode($course)->Channel->description); ?></div>
                    </div>

                    <div class="widget widget-ads text-center">
                        ADSS

                    </div>


                    <div class="widget">
                        <h3><a href="https://www.sfahat.com" target="_blank"><img src="/images/sfahat-logo.png"></a></h3>
                        <div class="widget-body">

                            <ul class="articles-list">


                                <li>
                                    <div class="article-item">
                                        <a href="https://www.sfahat.com/article/41/أفضل-بيئات-تطوير-تطبيقات-الهاتف-الهجينة-hybrid-لعام-2020" target="_blank">
                                            <img src="https://www.sfahat.com/uploads/thumbnails/2019/12/1f167fedb78d37bf66000dd03b0ecf5fecf29d85.jpg">
                                            أفضل بيئات تطوير تطبيقات الهاتف الهجينة Hybrid لعام 2020                </a>
                                        <div class="article-date">24/12/2019</div>
                                    </div>
                                    <div style="clear: both;"></div>
                                </li>

                            </ul>
                        </div>
                    </div>

                    <div class="widget share-course">
                        <h3><i class="fa fa-share-alt"></i> شارك الكورس</h3>

                        <div class="course-link-input">
                            <input class="form-control" onclick="selectInput(this)" value="https://www.coursat.org/c/350" readonly="">
                        </div>

                        <ul class='list-unstyled share-buttons'>

                            <li>
                                <a class='sharing-button facebook' href='https://facebook.com/sharer/sharer.php?u=https://www.coursat.org/course/350/برمجة-الويب-باستخدام-إطار-laravel-55' title='facebook' target='_blank'>
                                    <i class='fa fa-facebook'></i>
                                </a>
                            </li>

                            <li>
                                <a class='sharing-button twitter' href='https://twitter.com/intent/tweet/?text=برمجة الويب باستخدام إطار Laravel 5.5&url=https://www.coursat.org/course/350/برمجة-الويب-باستخدام-إطار-laravel-55' title='twitter' target='_blank'>
                                    <i class='fa fa-twitter'></i>
                                </a>
                            </li>

                            <li>
                                <a class='sharing-button google-plus' href='https://plus.google.com/share?url=https://www.coursat.org/course/350/برمجة-الويب-باستخدام-إطار-laravel-55' title='google plus' target='_blank'>
                                    <i class='fa fa-google-plus'></i>
                                </a>
                            </li>

                            <li>
                                <a class='sharing-button email' href='mailto:?subject=برمجة الويب باستخدام إطار Laravel 5.5&body=https://www.coursat.org/course/350/برمجة-الويب-باستخدام-إطار-laravel-55' title='email' target='_self'>
                                    <i class='fa fa-envelope'></i>
                                </a>
                            </li>

                            <li>
                                <a class='sharing-button whatsapp' href='https://api.whatsapp.com/send?text=https://www.coursat.org/course/350/برمجة-الويب-باستخدام-إطار-laravel-55' title='whatsapp' target='_blank'>
                                    <i class='fa fa-whatsapp'></i>
                                </a>
                            </li>

                        </ul>
                    </div>

                </div>
            </div>

        </div>
    </div>
<?php endif; ?>
<?php echo $__env->make('pages.Main_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ITcorses\resources\views/view_course.blade.php ENDPATH**/ ?>