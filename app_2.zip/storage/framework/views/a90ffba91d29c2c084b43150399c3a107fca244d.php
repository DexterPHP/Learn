
<!-- Footer -->

<div class="footer">

    <div class="container">
        <div class="row">

            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <img class="logo-footer" src="/images/logo.png">
                <div class="about-footer">كورسات هي منصة عربية توفر كورسات مجانية عالية الجودة في مختلف المجالات والتخصصات تسعى إلى رفع مستوى التعليم الإلكتروني في الوطن العربي كما توفر فرصة لاصحاب الكفاءات والخبرات والمدرسين للوصول إلى جمهور أكبر</div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <h3>كورسات</h3>
                <ul class="list-unstyled footer-links">
                    <li><a href="about.html">نبذة عن كورسات</a></li>
                    <li><a href="terms.html">شروط الاستخدام</a></li>
                    <li><a href="faq.html">الأسئلة الشائعة</a></li>
                    <li><a href="privacy-policy.html">سياسة الخصوصية</a></li>
                    <li><a href="https://www.semaat.com/blog/category/coursat" target="_blank">المدونة</a></li>
                    <li><a href="https://www.semaat.com/contact" target="_blank">اتصل بنا</a></li>
                </ul>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <h3>روابط</h3>
                <ul class="list-unstyled footer-links">
                    <li><a href="https://www.coursat.org/submit-course">اقتراح كورس</a></li>
                    <li><a href="https://www.coursat.org/request-course">طلب كورس</a></li>
                    <li><a href="https://www.coursat.org/join-us">انضم إلينا كمحاضر</a></li>
                    <li><a href="verify.html">تحقق من صحة الشهادة</a></li>
                </ul>
            </div>

            <div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
                <h3>تابعنا</h3>
                <ul class="list-unstyled footer-social">
                    <li><a href="https://twitter.com/coursatorg" class="twitter"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="https://web.facebook.com/coursat.org" class="facebook"><i class="fa fa-facebook"></i></a></li>
                </ul>
            </div>

        </div>
    </div>

    <div class="copyright text-center">
        &copy; 2020 <span><a href="index.htm">كورسات</a></span> ، أحد مشاريع <span><a href="https://www.semaat.com">سمات</a></span>. جميع الحقوق محفوظة.
    </div>

    <!-- Semaat Footer -->

    <div class="container">

        <div class="semaat-footer">
            <div class="semaat-logo">
                <a href="https://www.semaat.com" target="_blank">
                    <img src="<?php echo e(asset('images/semaat-footer/semaat.png')); ?>">
                </a>
            </div>

            <div class="item">
                <a href="https://www.acoderlab.com" target="_blank" title="مختبر المبرمج - برمجة وتصميم مواقع الإنترنت بأحدث تقنيات الويب">
                    <img src="<?php echo e(asset('images/semaat-footer/acoderlab.png')); ?>">
                    <div class="item-name">مختبر المبرمج</div>
                </a>
            </div>

            <div class="item">
                <a href="index.htm" target="_blank" title="كورسات - كورسات مجانية في مختلف المجالات">
                    <img src="<?php echo e(asset('images/semaat-footer/coursat.png')); ?>">
                    <div class="item-name">كورسات</div>
                </a>
            </div>

            <div class="item">
                <a href="https://www.sfahat.com" target="_blank" title="صفحات - مقالات تقنية بجودة عالية">
                    <img src="<?php echo e(asset('images/semaat-footer/sfahat.png')); ?>">
                    <div class="item-name">صفحات</div>
                </a>
            </div>

        </div>

    </div>

</div>

<!-- End Footer -->

</body>

</html>

<!-- JavaScript -->
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/rating.js')); ?>"></script>
<script src="<?php echo e(asset('js/plugins.js')); ?>"></script>

<!--[if lt IE 9]>
<script src="<?php echo e(asset('js/html5shiv.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/respond.min.js')); ?>"></script>
<![endif]-->

<!-- Google Analytics -->

<!-- END Google Analytics -->
<?php /**PATH C:\xampp\htdocs\ITcorses\resources\views/pages/Main_footer.blade.php ENDPATH**/ ?>