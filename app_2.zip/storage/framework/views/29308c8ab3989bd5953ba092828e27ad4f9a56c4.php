<?php echo $__env->make('pages.Main_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<title>ويكي كورس |تصنيفات الأقسام الرئيسية</title>

<section class="coursat-intro text-center">
    <link rel="stylesheet" href="<?php echo e(asset('css/slider.css')); ?>">
    <div class="container intro-bg">
        <div id="slider" class="slider">
            <div class="slider-item active" style="background-image: url(<?php echo e(asset('images/0.jpg')); ?>)"></div>
            <div class="slider-item" style="background-image: url(<?php echo e(asset('images/networking.jpg')); ?>)"></div>
            <div class="slider-item" style="background-image: url(<?php echo e(asset('images/1.jpg')); ?>)"></div>
            <div class="slider-item" style="background-image: url(<?php echo e(asset('images/2.jpg')); ?>)"></div>
            <div class="slider-item" style="background-image: url(<?php echo e(asset('images/intro-bg.jpg')); ?>)"></div>
            <div class="slider-panel">
                <div class="slider-panel__navigation">
                    <i class="fa fa-circle indicator active" data-slide-to="0"></i>
                    <i class="fa fa-circle indicator" data-slide-to="1"></i>
                    <i class="fa fa-circle indicator" data-slide-to="2"></i>
                    <i class="fa fa-circle indicator" data-slide-to="3"></i>
                    <i class="fa fa-circle indicator" data-slide-to="4"></i>
                </div>
                <div class="slider-panel__controls">
                    <i class="fa fa-arrow-circle-right " id="next"></i>
                    <i class="fa fa-pause" id="pause-play"></i>
                    <i class="fa fa-arrow-circle-left" id="previous"></i>
                </div>
            </div>
        </div>

    </div>
</section>
<!-- Header And Navbar -->

<section class="categories categories-home text-center">
    <div class="container">
        <div class="big-title">
            <h2> جميع تصنيفات االكورسات</h2>
            <div class="hr-title"></div>
        </div>


        <div class="row">

            <?php $__currentLoopData = $cater; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-4">
                    <a href="MainCourse/<?php echo e($category->title_en); ?>">
                        <div class="category-box" title="<?php echo e($category->description); ?>">
                            <div class="category-cover" style="background:url('<?php echo e($category->image_link); ?>') no-repeat center center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;">
                                <div class="category-overlay">
                                    <div class="thumb-content">
                                        <div class="category-icon">
                                            <i class="<?php echo e($category->icon_link); ?>"></i>
                                        </div>
                                        <div class="category-name"><?php echo e($category->title); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>

    </div>
</section>


<?php echo $__env->make('pages.Main_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/wikicourses/resources/views/main/index2.blade.php ENDPATH**/ ?>