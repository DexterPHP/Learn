<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\MainCater;
use Faker\Generator as Faker;

$factory->define(MainCater::class, function (Faker $faker) {
    return [
        //
    ];
});
