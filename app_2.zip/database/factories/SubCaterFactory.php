<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\SubCater;
use Faker\Generator as Faker;

$factory->define(SubCater::class, function (Faker $faker) {
    return [
        //
    ];
});
